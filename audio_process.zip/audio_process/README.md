# Audio Transcription and Summarization with FastAPI

## Setup

1. Install dependencies:
    ```sh
    pip install -r requirements.txt
    ```

2. Run the FastAPI server:
    ```sh
    uvicorn main:app --reload
    ```

3. Test the endpoint:
    - Upload an audio file to the `/process-audio/` endpoint using a tool like Postman or curl.
