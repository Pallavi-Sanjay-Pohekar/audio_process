# utils/file_handler.py
import aiofiles
from fastapi import UploadFile

async def save_file(file: UploadFile) -> str:
    file_path = f"uploads/{file.filename}"
    async with aiofiles.open(file_path, 'wb') as out_file:
        content = await file.read()
        await out_file.write(content)
    return file_path
