# models/whisper_large_v3.py
import whisper

class WhisperTranscriber:
    def __init__(self):
        self.model = whisper.load_model("large-v3")

    def transcribe(self, file_path: str) -> str:
        result = self.model.transcribe(file_path)
        return result['text']
