# transcriber.py
from models.whisper_large_v3 import WhisperTranscriber

def transcribe_audio(file_path: str) -> str:
    transcriber = WhisperTranscriber()
    transcription = transcriber.transcribe(file_path)
    return transcription
