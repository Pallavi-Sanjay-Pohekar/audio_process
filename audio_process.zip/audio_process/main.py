# main.py
from fastapi import FastAPI, UploadFile, File
from transcriber import transcribe_audio
from summarizer import summarize_text
from timestamp_extractor import extract_timestamps
from utils.file_handler import save_file

app = FastAPI()


@app.post("/process-audio/")
async def process_audio(file: UploadFile = File(...)):
    file_path = await save_file(file)
    transcription = transcribe_audio(file_path)
    summary = summarize_text(transcription)
    timestamps = extract_timestamps(file_path, transcription)

    result = {
        "transcription": transcription,
        "summary": summary,
        "timestamps": timestamps
    }
    return result


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8000)
